//
//  Comment.swift
//  ZemogaTechTest-Version1
//
//  Created by DXC Technologies CR on 8/9/22.
//

import Foundation

struct Comment: Codable {
    var postId: Int
    var id: Int
    var name: String
    var email: String
    var body: String
}
