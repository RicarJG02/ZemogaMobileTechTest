//
//  ZemogaTechTest_Version1App.swift
//  ZemogaTechTest-Version1
//
//  Created by DXC Technologies CR on 8/9/22.
//

import SwiftUI

@main

struct ZemogaTechTest_Version1App: App {
    @StateObject private var dataController = DataController()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, dataController.container.viewContext)
                .environmentObject(dataController)
        }
    }
}
