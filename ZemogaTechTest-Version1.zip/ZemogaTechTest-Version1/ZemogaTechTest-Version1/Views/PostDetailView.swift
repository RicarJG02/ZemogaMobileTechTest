//
//  PostDetailView.swift
//  ZemogaTechTest-Version1
//
//  Created by DXC Technologies CR on 8/9/22.
//

import SwiftUI

struct PostView: View {
    
    var post: Post
    var users: [User]
    var comments: [Comment]
    
    @Binding var favPosts: [Post]
    @State var addToFav = false
    
    var delFunction: () -> Void
    var addToFavFun: () -> Void
    
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20){
           
            Text("User 👨🏼‍💻")
                .font(.title2)
                .bold()
            userVStack()
            
            Divider()
                .frame(width: 325, height: 1)
                .overlay(.green)
            
            Text("Description 👓")
                .font(.title2)
                .bold()
            Text(post.body)
                .foregroundColor(.gray)
                .font(.system(size: 15))
                .multilineTextAlignment(.leading)
            
            Divider()
                .frame(width: 325, height: 1)
                .overlay(.green)
            
            Text("Comments 📗")
                .font(.title2)
                .bold()
            
            VStack(alignment: .leading){
                ScrollView {
                    ForEach(comments.filter({$0.postId == post.id}) , id: \.id){ comment in
                        VStack(alignment: .leading, spacing: 20){
                        Text(comment.body)
                            .foregroundColor(.gray)
                            .font(.system(size: 15))
                            .multilineTextAlignment(.leading)
                        Divider()
                            .overlay(.green)
                        }
                    }
                }
            }
        }.padding([.top, .leading], 30)
            .edgesIgnoringSafeArea(.bottom)
            .toolbar {
                HStack{
                    Button {
                        addToFav.toggle()
                        if addToFav { favPosts.append(post) }else { favPosts = favPosts.filter({$0.id == post.id}) }
                    } label: {
                        Image(systemName: addToFav ? "star.fill" : "star").foregroundColor(.yellow)
                    }
                    Button {
                        dismiss.callAsFunction()
                        delFunction()
                    } label: {
                        Image(systemName: "trash.fill").foregroundColor(.black)
                    }
                }
            }
            .onDisappear {
                if favPosts.contains(where: {$0.id == post.id}){
                    addToFavFun()
                }
            }
    }
    @ViewBuilder
    func userVStack() -> some View {
        VStack(alignment: .leading, spacing: 10){
            Text("Name \(users.first(where: {$0.id == post.userId})?.name ?? "error")")
            Text("Email \(users.first(where: {$0.id == post.userId})?.email ?? "error")")
            Text("Phone \(users.first(where: {$0.id == post.userId})?.phone ?? "error")")
            Text("Website \(users.first(where: {$0.id == post.userId})?.website ?? "error")")
        }.foregroundColor(.gray)
            .font(.system(size: 15))
            .multilineTextAlignment(.leading)
    }
}


