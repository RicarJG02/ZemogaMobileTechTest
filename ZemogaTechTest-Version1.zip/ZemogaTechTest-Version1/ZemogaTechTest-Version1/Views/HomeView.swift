//
//  HomeView.swift
//  ZemogaTechTest-Version1
//
//  Created by DXC Technologies CR on 8/9/22.
//

import UIKit
import SwiftUI
import CoreData

struct HomeView: View {
    
    @FetchRequest(sortDescriptors: []) var favPostCD: FetchedResults<CDFavPost>
    @FetchRequest(sortDescriptors: []) var postsCD: FetchedResults<CDPost>
    @FetchRequest(sortDescriptors: []) var userCD: FetchedResults<CDUser>
    @FetchRequest(sortDescriptors: []) var commentCD: FetchedResults<CDComment>
    
    @Environment(\.managedObjectContext) var moc
    
    @State var posts = [Post]()
    @State var users = [User]()
    @State var comments = [Comment]()
    
    @State var pickerOptions = ["All posts", "Favorites"]
    @State var pickerID = 0
    
    @State var deletedPosts = [Post]()
    @State var favposts = [Post]()
    
    @EnvironmentObject var dataController: DataController
    
    var newPosts: [Post] {
        let array = posts.filter { post in
            deletedPosts.contains(where: {post.id == $0.id})
        }
        return array
    }
   
    // UIKit - UI mods
    
    init() {
        UISegmentedControl.appearance().selectedSegmentTintColor = UIColor.systemGreen
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor : UIColor.black], for: .selected)
    }
    
    // UI in the making...
    
    var body: some View {
        
        NavigationView {
            
            VStack{
                
                Picker("", selection: $pickerID) {
                    ForEach(0..<pickerOptions.count, id: \.self) { i in Text(pickerOptions[i]) }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal,30)
                .padding()
                
                ZStack{
                    if pickerID == 0 {
                        
                        VStack {
                            List(Array(zip(posts.indices, posts)), id: \.0){ index, post in
                                NavigationLink {
                                    PostView(post: post, users: users, comments: comments, favPosts: $favposts, delFunction: {
                                        posts.remove(at: index)
                                        dataController.deletePost(moc: moc, post: postsCD)
                                        dataController.fetchPosts(posts: posts, moc: moc, post: _postsCD)
                                    }, addToFavFun: {
                                        posts.move(fromOffsets: IndexSet(integer: index), toOffset: 0)
                                        dataController.deletefavPost(moc: moc, post: favPostCD)
                                        dataController.fetchFavPosts(favposts: favposts, moc: moc, post: _favPostCD)
                                    })
                                }
                                label: {
                                    HStack(spacing: 15) {
                                        Image(systemName: favposts.contains(where: {$0.id == post.id}) ? "star.fill" : "").foregroundColor(.yellow)
                                        Text(post.body)
                                            .foregroundColor(.gray)
                                            .multilineTextAlignment(.leading)
                                            .lineLimit(3)
                                            .font(.system(size: 14))
                                    }
                                }
                            }
                        }
                    }
                    else {
                        VStack {
                            List(favposts, id: \.id) { post in
                                NavigationLink {
                                    PostView(post: post, users: users, comments: comments, favPosts: $favposts, delFunction: {
                                        
                                    }, addToFavFun: {
                                        
                                    })
                                } label: {
                                    HStack(spacing: 15) {
                                        Image(systemName: favposts.contains(where: {$0.id == post.id}) ? "star.fill" : "").foregroundColor(.yellow)
                                        Text(post.body)
                                            .foregroundColor(.gray)
                                            .multilineTextAlignment(.leading)
                                            .lineLimit(3)
                                            .font(.system(size: 14))
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer()
                Button {
                    posts = [Post]()
                    favposts = [Post]()
                
                    dataController.deletePost(moc: moc, post: postsCD)
                    dataController.deletefavPost(moc: moc, post: favPostCD)
                    
                } label: {
                    ZStack{
                        Rectangle().fill(.red).frame(height: 70)
                        Text("Delete all")
                            .foregroundColor(.white)
                    }
                }
            }
            .edgesIgnoringSafeArea(.bottom)
            .navigationBarTitleDisplayMode(.inline)
            .navigationTitle("Zemoga")
            .toolbar {
                Button {
                    Task {
                        await loadData()
                        dataController.fetchPosts(posts: posts, moc: moc, post: _postsCD)
                        dataController.fetchUsers(users: users, moc: moc, user: _userCD)
                        dataController.fetchComments(comments: comments, moc: moc, comment: _commentCD)
                        dataController.fetchFavPosts(favposts: favposts, moc: moc, post: _favPostCD)
                        print(favposts.count, "Set")
                    }
                } label: {
                    Image(systemName: "arrow.clockwise").foregroundColor(.green)
                }
            }
        }
        .onAppear(perform: {
            
            var arrayP = [Post]()
            var arrayC = [Comment]()
            var arrayU = [User]()
            var arrayF = [Post]()
            
            for i in postsCD {
                arrayP.append(Post(userId: Int(i.userId), id: Int(i.id), title: i.title ?? "", body: i.body ?? ""))
            }
            posts = arrayP
            
            for i in userCD {
                arrayU.append(User(id: Int(i.id), name: i.name ?? "", email: i.email ?? "", phone: i.phone ?? "", website: i.website ?? ""))
            }
            users = arrayU
            
            for i in commentCD {
                arrayC.append(Comment(postId: Int(i.postId), id: Int(i.id), name: i.name ?? "", email: i.email ?? "", body: i.body ?? ""))
            }
            
            comments = arrayC
            
            for i in favPostCD {
                arrayF.append(Post(userId: Int(i.userId), id: Int(i.id), title: i.title ?? "", body: i.body ?? ""))
            }
            
            favposts = arrayF
            
        })
        .edgesIgnoringSafeArea(.bottom)
    }
    
    // Functions for making the UI Usefull
    
    func loadData() async {
        await loadPosts()
        await loadUsers()
        await loadComments()
    }
    
    func loadPosts() async {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts/") else {
            print("Something went wrong")
            return
        }
        
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            if let decodedResponse = try? JSONDecoder().decode([Post].self, from: data){
                posts = decodedResponse
            }
        } catch {
            print("Invalid data")
        }
    }
    
    func loadUsers() async {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/users/") else {
            print("Something went wrong")
            return
        }
        
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            if let decodedResponse = try? JSONDecoder().decode([User].self, from: data){
                users = decodedResponse
            }
        } catch {
            print("Invalid data")
        }
    }
    
    func loadComments() async {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/comments/") else {
            print("Something went wrong")
            return
        }
        
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            if let decodedResponse = try? JSONDecoder().decode([Comment].self, from: data){
                comments = decodedResponse
            }
        } catch {
            print("Invalid data")
        }
    }
}
