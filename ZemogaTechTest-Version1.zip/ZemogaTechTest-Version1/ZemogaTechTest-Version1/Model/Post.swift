//
//  Post.swift
//  ZemogaTechTest-Version1
//
//  Created by DXC Technologies CR on 8/9/22.
//

import Foundation

struct Post: Codable {
    var userId: Int
    var id: Int
    var title: String
    var body: String
}
