//
//  User.swift
//  ZemogaTechTest-Version1
//
//  Created by DXC Technologies CR on 8/9/22.
//

import Foundation

struct User: Codable {
    var id: Int
    var name: String
    var email: String
    var phone: String
    var website: String
}
