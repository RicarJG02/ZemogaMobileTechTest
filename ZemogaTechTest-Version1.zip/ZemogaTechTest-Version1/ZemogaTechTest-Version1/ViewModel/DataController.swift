//
//  DataController.swift
//  ZemogaTechTest-Version1
//
//  Created by DXC Technologies CR on 8/9/22.
//

import CoreData
import SwiftUI
import Foundation


class DataController: NSObject, ObservableObject {
    let container = NSPersistentContainer(name: "DataModel")
    
    override init() {
        container.loadPersistentStores { description, error in
            if let error = error {
                print("idk: \(error)")
            }
        }
    }
    
    func fetchPosts(posts: [Post], moc: NSManagedObjectContext, post: FetchRequest<CDPost>) {
        for i in posts {
            
            let post = CDPost(context: moc)
            
            post.userId = Int64(i.userId)
            post.id = Int64(i.id )
            post.title = i.title
            post.body = i.body
            
            try? moc.save()
        }
    }
    
    func fetchFavPosts(favposts: [Post], moc: NSManagedObjectContext, post: FetchRequest<CDFavPost>) {
        for i in favposts {
            
            let post = CDFavPost(context: moc)
            
            post.userId = Int64(i.userId)
            post.id = Int64(i.id )
            post.title = i.title
            post.body = i.body
            
            try? moc.save()
        }
    }
    
    func fetchUsers(users: [User], moc: NSManagedObjectContext, user: FetchRequest<CDUser>) {
    
        for i in users {
            let user = CDUser(context: moc)
            user.id = Int64(i.id)
            user.name = i.name
            user.email = i.email
            user.phone = i.phone
            user.website = i.website
            
            try? moc.save()
        }
    }
    
    func fetchComments(comments: [Comment], moc: NSManagedObjectContext, comment: FetchRequest<CDComment>) {
        
        for i in comments {
            let comment = CDComment(context: moc)
            comment.postId = Int64(i.postId)
            comment.id = Int64(i.id)
            comment.name = i.name
            comment.email = i.email
            comment.body = i.body
            
            try? moc.save()
        }
    }
    
    // Functions of Delete Posts or Delte if it is fav
    
    func deletePost(moc: NSManagedObjectContext, post: FetchedResults<CDPost>){
        do {
            for item in post {
                moc.delete(item)
            }
            try moc.save()

        } catch {
            
        }
    }
    
    func deletefavPost(moc: NSManagedObjectContext, post: FetchedResults<CDFavPost>){
        do {
            for item in post {
                moc.delete(item)
            }
            try moc.save()

        } catch {
            
        }
    }
    
}

// Note : This could be improve in order to provide a more generic code and use it in both cases.
// But it would take more time to think it and go about it. But for the long run and bigger project is
// better to invest the time and energy.
